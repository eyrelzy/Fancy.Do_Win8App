﻿function getStyle() {
    return [
        { "sno": "01", "sname": "A", "sdes": "acb", "simg": "images/ok.png", "scat": "YY", "stime": "", "sloc": "" },
        { "sno": "02", "sname": "B", "sdes": "acb", "simg": "images/phone.png", "scat": "YY", "stime": "", "sloc": "" },
        { "sno": "03", "sname": "C", "sdes": "acb", "simg": "images/phone.png", "scat": "YY", "stime": "", "sloc": "" },
        { "sno": "04", "sname": "D", "sdes": "acb", "simg": "images/phone.png", "scat": "YY", "stime": "", "sloc": "" },
        { "sno": "05", "sname": "E", "sdes": "acb", "simg": "images/phone.png", "scat": "YY", "stime": "", "sloc": "" },
        { "sno": "06", "sname": "F", "sdes": "acb", "simg": "images/day.png", "scat": "YY", "stime": "", "sloc": "" }
    ];
}
function getGTD() {
    return [
        { "GTDno": "01", "GTDdes": "A", "GTDremark": "abc", "GTDloc": "Ab4", "GTDlevel": "5", "GTDfile": "ba0", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/mess.png" },
        { "GTDno": "01", "GTDdes": "B", "GTDremark": "abc", "GTDloc": "Ab4", "GTDlevel": "5", "GTDfile": "ba0", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "C", "GTDremark": "abc", "GTDloc": "Ab4", "GTDlevel": "5", "GTDfile": "ba0", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/meal.png" },
        { "GTDno": "01", "GTDdes": "A2", "GTDremark": "abc", "GTDloc": "Ab4", "GTDlevel": "4", "GTDfile": "ba0", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/phone.png" },
        { "GTDno": "01", "GTDdes": "A3", "GTDremark": "abc", "GTDloc": "Ab4", "GTDlevel": "4", "GTDfile": "ba0", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/ok.png" },
        { "GTDno": "01", "GTDdes": "A4", "GTDremark": "abc", "GTDloc": "Ab4", "GTDlevel": "4", "GTDfile": "ba0", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/book.png" },
        { "GTDno": "01", "GTDdes": "A6", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "4", "GTDfile": "ba0", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Af", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "3", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Ad", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "3", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Aw", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "3", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Aq", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "2", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Ab", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "2", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Aw5", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "2", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Aq2", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "1", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" },
        { "GTDno": "01", "GTDdes": "Ab23", "GTDremark": "abc", "GTDloc": "Ab7", "GTDlevel": "1", "GTDfile": "ba7", "GTDdate": "6/30/2002", "GTDtime": "13:30", "GTDimg": "images/time.png" }


    ];
}
function getloc() {
    return [
        { "locno": "01", "locname": "Ab1" },
        { "locno": "01", "locname": "Ab2" },
        { "locno": "01", "locname": "Ab3" },
        { "locno": "01", "locname": "Ab4" },
        { "locno": "01", "locname": "Ab5" },
        { "locno": "01", "locname": "Ab6" },
        { "locno": "01", "locname": "Ab7" },
        { "locno": "01", "locname": "Ab8" }
    ];
}
function getfile() {
    return [
        { "fileno": "01" , "filename": "ba0" },
        { "fileno": "01" , "filename": "ba1" },
        { "fileno": "01" , "filename": "ba2" },
        { "fileno": "01" , "filename": "ba3" },
        { "fileno": "01" , "filename": "ba5" },
        { "fileno": "01" , "filename": "ba6" },
        { "fileno": "01" , "filename": "ba7" },
        { "fileno": "01" , "filename": "ba8" }
    ];
}
function getimg() {
    return [
        {"src":"images/mess.png","name":"message"},
        { "src": "images/meal.png", "name": "meal" },
        { "src": "images/meeting.png", "name": "meeting" },
        { "src": "images/ok.png", "name": "easy" },
        { "src": "images/phone.png", "name": "phone" },
        { "src": "images/book.png", "name": "book" },
        { "src": "images/time.png", "name": "clock" },
        { "src": "images/day.png", "name": "day" }
    ];
}
    $("#goto").ready(function () {
        $("#gototime").click(function () {
            $(".respect").fadeOut();
            $("#timeview").fadeIn();
        });
        $("#gotoloc").click(function () {
            $(".respect").fadeOut();
            $("#locview").fadeIn();
        });
        $("#gotofile").click(function () {
            $(".respect").fadeOut();
            $("#fileview").fadeIn();
        });
        $("#gotoadd").click(function () {
            $(".respect").fadeOut();
            $("#addGTD").fadeIn();
        });
        $("#gotoads").click(function () {
            $(".respect").fadeOut();
            $("#addstyle").fadeIn();
        });
        $("#gotologin").click(function () {
            $(".respect").fadeOut();
            $("#container_demo").fadeIn();
        });
    });