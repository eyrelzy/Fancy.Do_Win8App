﻿//定义一些会被改变的变量适用于各个地方的改变
var style;
var loc;
var file;
var dis;
//读取并显示出时间（可编辑）
function readGTDjson(a) {
    WinJS.UI.processAll();
    $("#disgdele").attr("title",a.GTDno);
    $("#disgnamein").attr("value", a.GTDdes);
    $("#disgimgdis").attr("src", a.GTDimg);
    $("#disgremin").html(a.GTDremark);
    var dp = document.getElementById("disgdate").winControl;
    //dp.current = new Date(a.GTDdate);
    dp.current = a.GTDdate;
    var tp = document.getElementById("disgtime").winControl;
    var st = "January 20,2013 " + a.GTDtime + ":5"
    tp.current = new Date(st);
    var rp = document.getElementById("disglevelin").winControl;
    rp.userRating = a.GTDlevel;
    var loc = a.GTDloc;
    var title = document.getElementById('disglocin');
    for (var i = 0; i < title.options.length; i++) {
        if (title.options[i].innerHTML == loc) {
            title.options[i].selected = true;
            break;
        }
    }
    var file = a.GTDfile;
    title = document.getElementById('disgfilein');
    for (var i = 0; i < title.options.length; i++) {
        if (title.options[i].innerHTML == file) {
            title.options[i].selected = true;
            break;
        }
    }
    var img = a.GTDimg;
    title = document.getElementById('disgimgin');
    for (var i = 0; i < title.options.length; i++) {
        if (title.options[i].value == img) {
            title.options[i].selected = true;
            break;
        }
    }

}
//addGTD页面刷新
function addGTDready() {
    style = displayAllStyle();
    style = displayAllStyle();
    var page = 0;//已经显示过的数目
    for (var i = 0; i < 8; i++) {
        var agb = "#agb" + i;
        if (page >= style.length) {
            //page = 0;
            //$(agb).html(style[page].sname);
            $(agb).attr("title", page);
            $(agb).html(" ");
            //$(agb).hide();
        }
        else {
            //$(agb).show();
            $(agb).html(style[page].sname);
            $(agb).attr("title", page);
        }
        page++;
    }
    //if (page >= style.length) page = 0;
    $("#addGTD").hammer().on("swiperight", function (ev) {
        if (page >= style.length) page = 0;
        for (var i = 0; i < 8; i++) {
            var agb = "#agb" + i;
            if (page >= style.length) {
                //page = 0;
                //$(agb).html(style[page].sname);
                $(agb).attr("title", page);
                $(agb).html(" ");
            }
            else {
                $(agb).html(style[page].sname);
                $(agb).attr("title", page);
            }
            page++;
        }

        $(".block").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".block").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#addGTD").hammer().on("swipeleft", function (ev) {
        //if (page != 0) {
        for (var i = 0; i < 16; i++) {
            page--;
            if (page < 0) {
                //page = style.length - 1;
                page = style.length + 8 - style.length % 8 - 1;
            }
        }
        //}
        if (page >= style.length) page = 0;
        for (var i = 0; i < 8; i++) {
            var agb = "#agb" + i;
            if (page >= style.length) {
                //page = 0;
                //$(agb).html(style[page].sname);
                $(agb).attr("title", page);
                $(agb).html(" ");
            }
            else {
                $(agb).html(style[page].sname);
                $(agb).attr("title", page);
            }
            page++;
        }
        //if (page >= style.length) page = 0;
        $(".block").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".block").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".addnew").click(function () {
        $("#manageGTD").fadeIn();
    });
    $(".block").click(function () {
        $("#manageGTD").fadeIn();
        var i = $(this).attr("title");
        if (i >= style.length) {
            $("#magnamein").val("");
        }
        else {
            $("#magnamein").val(style[i].sname);
            var img = style[i].simg;
            document.getElementById('magimgdis').src = img;
        }
        var title = document.getElementById('magimgin');
        for (var i = 0; i < title.options.length; i++) {
            if (title.options[i].value == img) {
                title.options[i].selected = true;
                break;
            }
        }
    });
}
//deleteGTD页面刷新
function deleteGTDready() {
    style = displayAllStyle();
    $("#delestyle").html("");
    for (var i = 0; i < style.length; i++) {
        var n = style[i].sname;
        var img = style[i].simg;
        $("#delestyle").append("</div>");
        $("#delestyle").append("</div>");
        $("#delestyle").append("<div class='delebutton' id=" + style[i].sno + ">DELETE");
        $("#delestyle").append("<img src=" + img + " class='deleimg'/>");
        $("#delestyle").append("<div class='delediv' title=" + i + ">" + n);
    }
    $("#delestyle").hammer().on("swipeup", function (ev) {
        $("#delestyle").slideUp();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".delediv").hammer().on("swipeleft", function (ev) {
        var but = style[$(this).attr("title")].sno;
        var i = $("#" + but).css("width");
        if ($("#" + but).css("width") == "0px") $("#" + but).animate({ width: '30%' });;
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".delediv").hammer().on("swiperight", function (ev) {
        var but = style[$(this).attr("title")].sno;
        if ($("#" + but).css("width") != "0px") $("#" + but).animate({ width: '0%' });

        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".delebutton").click(function () {
        var but = $(this).attr("id");
        delStyle(but);
        $("#" + but).animate({ width: '0%' });
        addGTDready();
        $("#delestyle").slideUp();
        //window.location.reload();
        //window.location.replace("./default.html#delestyle");
        //$("#testout").append(but);
    });
}
//locview页面刷新
function locviewready() {
    ///初始化地点展示窗
    loc = displayAllLoc();
    var page = 0;//展示地点用的计数变量
    for (var i = 0; i < 6; i++) {
        var lvb = "#lvb" + i;
        if (page >= loc.length) {
            page = 0;
            $(lvb).html(loc[page].locname);
            $(lvb).attr("title", page);
        }
        else {
            $(lvb).html(loc[page].locname);
            $(lvb).attr("title", page);
        }
        page++;
    }
    //定义展示事件用的变量
    var disp = 0;

    $("#locview").hammer().on("swipedown", function (ev) {
        $("#addloc").slideDown();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#locview").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var lvb = "#lvb" + i;
            if (page >= loc.length) {
                page = 0;
                $(lvb).html(loc[page].locname);
                $(lvb).attr("title", page);
            }
            else {
                $(lvb).html(loc[page].locname);
                $(lvb).attr("title", page);
            }
            page++;
        }
        $(".lvb").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".lvb").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });

    $(".lvb").click(function () {
        //根据选择初始化展示事件的变量
        var name = loc[$(this).attr("title")].locname;
        dis = displaylocGTD(loc[$(this).attr("title")].locname);
        dispage = 0;
        WinJS.UI.processAll();
        //初始化展示
        for (var i = 0; i < 6; i++) {
            var lvd = "#lvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvb).append("  ");
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            else {
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvb).append("  ");
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            dispage++;
        }
        $("#lvdishead").html(loc[$(this).attr("title")].locname);
        $("#lvdis").fadeIn();
    });
    $("#lvdis").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var lvd = "#lvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            else {
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".lvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".lvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#lvdis").hammer().on("swipeleft", function (ev) {
        for (var i = 0; i < 12; i++) {
            dispage--;
            if (dispage < 0) dispage = dis.length - 1;
        }
        for (var i = 0; i < 6; i++) {
            var lvd = "#lvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            else {
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".lvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".lvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#lvdishead").click(function () {
        $("#lvdis").fadeOut();
    });
    $(".lvd").click(function () {
        if (dis[$(this).attr("title")].GTDno != -1) {
            readGTDjson(dis[$(this).attr("title")]);
            $("#disGTD").fadeIn();
        }

    });
}
//fileview页面刷新
function fileviewready() {
    //展示文件夹的变量以及初始化
    file = displayAllFile();
    var page = 0;
    for (var i = 0; i < 6; i++) {
        var fvb = "#fvb" + i;
        if (page >= file.length) {
            page = 0;
            $(fvb).html(file[page].filename);
            $(fvb).attr("title", page);
        }
        else {
            $(fvb).html(file[page].filename);
            $(fvb).attr("title", page);
        }
        page++;
    }
    //定义展示事件用的变量
    var disp = 0;

    $("#fileview").hammer().on("swipedown", function (ev) {
        $("#addfile").slideDown();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#fileview").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var fvb = "#fvb" + i;
            if (page >= file.length) {
                page = 0;
                $(fvb).html(file[page].filename);
                $(fvb).attr("title", page);
            }
            else {
                $(fvb).html(file[page].filename);
                $(fvb).attr("title", page);
            }
            page++;
        }
        $(".fvb").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".fvb").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".fvb").click(function () {
        //根据选择初始化展示事件的变量
        //dis = getGTD(loc[$(this).attr("title")].locno);
        dis = displayfileGTD(file[$(this).attr("title")].filename);
        dispage = 0;
        WinJS.UI.processAll();
        //初始化展示
        for (var i = 0; i < 6; i++) {
            var fvd = "#fvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            else {
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            dispage++;
        }
        $("#fvdishead").html(file[$(this).attr("title")].filename);
        $("#fvdis").fadeIn();
    });
    $("#fvdis").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var fvd = "#fvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            else {
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".fvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".fvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#fvdis").hammer().on("swipeleft", function (ev) {
        for (var i = 0; i < 12; i++) {
            dispage--;
            if (dispage < 0) dispage = dis.length - 1;
        }
        for (var i = 0; i < 6; i++) {
            var fvd = "#fvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            else {
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".fvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".fvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#fvdishead").click(function () {
        $("#fvdis").fadeOut();
    });
    $(".fvd").click(function () {
        if (dis[$(this).attr("title")].GTDno != -1) {
            readGTDjson(dis[$(this).attr("title")]);
            $("#disGTD").fadeIn();
        }

    });

}
//timeview页面刷新
function timeviewready() {
    $("#tvdis").hide();
    $(".tvline").show();
    $(".tvline").css("border-color", "black");
    $(".tvline").unbind("click");
    var a;//判断点击的事today还是。。。。    
    var flag = 0;   
    //展示事件用的变量
    var disp = 0;
    //展示事件的函数
    function linedis() {
        if (a == "#tvtoday") {
            dis = showtodayGTD();
        }
        else if (a == "#tvtomo") {
            dis = showtomrrowGTD();
        }
        else if (a == "#tvhis") {
            dis = showhistoryGTD();
        }
        else if (a == "#tvfutu") {
            dis = showfutureGTD();
        }
        if (dis != null) {
            for (var i = 0; i < 6; i++) {
                var tvb = "#tvb" + i;
                if (disp >= dis.length) {
                    disp = 0;
                    $(tvb).html(dis[disp].GTDdes);
                    $(tvb).append("<br />");
                    $(tvb).append(dis[disp].GTDdate);
                    $(tvb).append("  ");
                    $(tvb).append(dis[disp].GTDtime);
                    $(tvb).append("<br />");
                    switch (dis[disp].GTDlevel) {
                        case '5':
                            $(tvb).css("background-color", "#FF0000")
                            $(tvb).css("color", "#FFFFFF")
                            break;
                        case '4':
                            $(tvb).css("background-color", "#FF8040")
                            $(tvb).css("color", "#000000")
                            break;
                        case '3':
                            $(tvb).css("background-color", "#FFFF37")
                            $(tvb).css("color", "#000000")
                            break;
                        case '2':
                            $(tvb).css("background-color", "#A8FF24")
                            $(tvb).css("color", "#000000")
                            break;
                        case '1':
                            $(tvb).css("background-color", "#00FFFF")
                            $(tvb).css("color", "#000000")
                            break;
                        case '0':
                            $(tvb).css("background-color", "#00FFFF")
                            break;

                    }
                    $(tvb).attr("title", disp);
                }
                else {
                    $(tvb).html(dis[disp].GTDdes);
                    $(tvb).append("<br />");
                    $(tvb).append(dis[disp].GTDdate);
                    $(tvb).append("  ");
                    $(tvb).append(dis[disp].GTDtime);
                    $(tvb).append("<br />");
                    switch (dis[disp].GTDlevel) {
                        case '5':
                            $(tvb).css("background-color", "#FF0000")
                            $(tvb).css("color", "#FFFFFF")
                            break;
                        case '4':
                            $(tvb).css("background-color", "#FF8040")
                            $(tvb).css("color", "#000000")
                            break;
                        case '3':
                            $(tvb).css("background-color", "#FFFF37")
                            $(tvb).css("color", "#000000")
                            break;
                        case '2':
                            $(tvb).css("background-color", "#A8FF24")
                            $(tvb).css("color", "#000000")
                            break;
                        case '1':
                            $(tvb).css("background-color", "#00FFFF")
                            $(tvb).css("color", "#000000")
                            break;
                        case '0':
                            $(tvb).css("background-color", "#00FFFF")
                            break;

                    }
                    $(tvb).attr("title", disp);
                }
                disp++;
            }
        }

    }
    //点击条目的函数
    function lineclick() {
        if (flag == 0) {
            flag = 1;
            $(".tvline").fadeOut(300);
            setTimeout(function () { $(a).css("border-color", "white"); }, 300);
            $(a).fadeIn();
            setTimeout(function () { $("#tvdis").slideDown(); }, 1000);
            //初始化事件列表
            disp = 0;
            linedis();
        }
        else if (flag == 1) {
            $(a).fadeOut(900);
            $("#tvdis").slideUp(900);
            setTimeout(function () {
                $(a).css("border-color", "black")
                $(".tvline").fadeIn();
            }, 1000);
            flag = 0;
        }
        else;
    }
    $("#tvtoday").click(function () {
        a = "#tvtoday";
        lineclick();
    });
    $("#tvtomo").click(function () {
        a = "#tvtomo";
        lineclick();
    });
    $("#tvhis").click(function () {
        a = "#tvhis";
        lineclick();
    });
    $("#tvfutu").click(function () {
        a = "#tvfutu";
        lineclick();
    });
    //左右滑动翻页
    $("#tvdis").hammer().on("swiperight", function (ev) {
        linedis();
        $(".tvblock").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".tvblock").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#tvdis").hammer().on("swipeleft", function (ev) {
        for (var i = 0; i < 12; i++) {
            disp--;
            if (disp < 0) disp = dis.length - 1;
        }
        linedis();
        $(".tvblock").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".tvblock").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".tvblock").click(function () {
        if (dis[$(this).attr("title")].GTDno != -1) {
            readGTDjson(dis[$(this).attr("title")]);
            $("#disGTD").fadeIn();
        }

    });
}
//magGTD刷新
function magGTDready() {
    var imgsrc = getimg();
    for (var i = 0; i < imgsrc.length; i++) {
        $("#magimgin").append("<option value =\"" + imgsrc[i].src + "\">" + imgsrc[i].name + "</option>");
    }
    //默认显示第一个
    document.getElementById("magimgdis").src = imgsrc[0].src;
    //图片选择器初始化设置完毕
    loc = displayAllLoc();
    file = displayAllFile();
    $("#maglocin").html("");
    $("#magfilein").html("");
    for (var i = 0; i < loc.length; i++) {
        $("#maglocin").append("<option value =\"" + loc[i].locname + "\">" + loc[i].locname + "</option>");
    }
    for (var i = 0; i < file.length; i++) {
        $("#magfilein").append("<option value =\"" + file[i].filename + "\">" + file[i].filename + "</option>");
    }
    //地点文件列表初始化完毕  
}
//disGTD刷新
function disGTDready() {
    var imgsrc = getimg();
    for (var i = 0; i < imgsrc.length; i++) {
        $("#disgimgin").append("<option value =\"" + imgsrc[i].src + "\">" + imgsrc[i].name + "</option>");
    }
    //图片选择器初始化设置完毕

    loc = displayAllLoc();
    file = displayAllFile();
    $("#disglocin").html("");
    $("#disgfilein").html("");
    for (var i = 0; i < loc.length; i++) {
        $("#disglocin").append("<option value =\"" + loc[i].locname + "\">" + loc[i].locname + "</option>");
    }
    for (var i = 0; i < file.length; i++) {
        $("#disgfilein").append("<option value =\"" + file[i].filename + "\">" + file[i].filename + "</option>");
    }
    //地点文件列表初始化完毕
}


$("#addGTD").ready(function () {
    style = displayAllStyle();
    var page = 0;//已经显示过的数目
    for (var i = 0; i < 8; i++) {
        var agb = "#agb" + i;
        if (page >= style.length) {
            //page = 0;
            //$(agb).html(style[page].sname);
            $(agb).attr("title", page);
            $(agb).html(" ");
            //$(agb).hide();
        }
        else {
            //$(agb).show();
            $(agb).html(style[page].sname);
            $(agb).attr("title", page);
        }
        page++;
    }
    //if (page >= style.length) page = 0;
    $("#addGTD").hammer().on("swiperight", function (ev) {
        if (page >= style.length) page = 0;
        for (var i = 0; i < 8; i++) {
            var agb = "#agb" + i;
            if (page >= style.length) {
                //page = 0;
                //$(agb).html(style[page].sname);
                $(agb).attr("title", page);
                $(agb).html(" ");
            }
            else {
                $(agb).html(style[page].sname);
                $(agb).attr("title", page);
            }
            page++;
        }
        
        $(".block").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".block").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#addGTD").hammer().on("swipeleft", function (ev) {
        //if (page != 0) {
            for (var i = 0; i < 16; i++) {
                page--;
                if (page < 0) {
                    //page = style.length - 1;
                    page = style.length + 8 - style.length % 8 - 1;
                }
            }
        //}
        if (page >= style.length) page = 0;
        for (var i = 0; i < 8; i++) {
            var agb = "#agb" + i;
            if (page >= style.length) {
                //page = 0;
                //$(agb).html(style[page].sname);
                $(agb).attr("title", page);
                $(agb).html(" ");
            }
            else {
                $(agb).html(style[page].sname);
                $(agb).attr("title", page);
            }
            page++;
        }
        //if (page >= style.length) page = 0;
        $(".block").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".block").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".addnew").click(function () {
        $("#manageGTD").fadeIn();
        //$("#addGTD").hide();
    });
    $(".block").click(function () {
        $("#manageGTD").fadeIn();
        var i = $(this).attr("title");
        if (i>=style.length) {
            $("#magnamein").val("");
        }
        else {
            $("#magnamein").val(style[i].sname);
            var img = style[i].simg;
            document.getElementById('magimgdis').src = img;
        }
        var title = document.getElementById('magimgin');
        for (var i = 0; i < title.options.length; i++) {
            if (title.options[i].value == img) {
                title.options[i].selected = true;
                break;
            }
        }
    });

});

$("#manageGTD").ready(function () {

    var imgsrc = getimg();
    for (var i = 0; i < imgsrc.length; i++) {
        $("#magimgin").append("<option value =\"" + imgsrc[i].src + "\">" + imgsrc[i].name + "</option>");
    }
    //默认显示第一个
    document.getElementById("magimgdis").src = imgsrc[0].src;
    //图片选择器初始化设置完毕


    //初始化地点和文件列表
    loc = displayAllLoc();
    file = displayAllFile();
    for (var i = 0; i < loc.length; i++) {
        $("#maglocin").append("<option value =\"" + loc[i].locname + "\">" + loc[i].locname + "</option>");
    }
    for (var i = 0; i < file.length; i++) {
        $("#magfilein").append("<option value =\"" + file[i].filename + "\">" + file[i].filename + "</option>");
    }
    //地点文件列表初始化完毕
    //初始化页面中得各个输入
    function initmag() {
        $("#magnamein").val("");
        $("#magremin").html("");
        document.getElementById("magimgdis").src = imgsrc[0].src;
        //var rp = document.getElementById("maglevelin").winControl;
        //rp.userRating = 0;
        //var now = new Date();
        //var dp = document.getElementById("magdate").winControl;
        //dp.current = now;
        //var tp = document.getElementById("magtime").winControl;
        //tp.current = now;
        var title = document.getElementById("maglocin");
        title.options[0].selected = true;
        title = document.getElementById("magfilein");
        title.options[0].selected = true;
        title = document.getElementById("magimgin");
        title.options[0].selected = true;
    }
    //图片选择更改
    $("#magimgin").change(function () {

        document.getElementById("magimgdis").src = $("#magimgin").val();
    });
    //点击ok
    $("#magok").click(function () {
        WinJS.UI.processAll();

        var name = $("#magnamein").attr("value");

        var img = $("#magimgin").attr("value");

        var dp = document.getElementById("magdate").winControl;
        var date = dp.current;
        var datestring = date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear();

        var tp = document.getElementById("magtime").winControl;
        var time = tp.current;
        var timestring = time.getHours() + ":" + time.getMinutes();

        //var rp = $("#maglevelin").winConrol;
        var rp = document.getElementById("maglevelin").winControl;
        var lev = rp.userRating;

        var loc = $("#maglocin").val();
        var file = $("#magfilein").val();
        var rem = $("#magremin").html();
        $("#testout").append(name);
        $("#testout").append(img);
        $("#testout").append(datestring);
        $("#testout").append(timestring);
        $("#testout").append(loc);
        $("#testout").append(file);
        $("#testout").append(rem);
        $("#testout").append(lev);
        addGTD();
        $("#manageGTD").hide();
        initmag();
        locviewready();
        fileviewready();
        timeviewready();
        //window.location.reload();
        //window.location.replace("./default.html#addGTD");
        //$("#manageGTD").fadeOut();
    });
    //点击cancel
    $("#magcan").click(function () {
        $("#manageGTD").fadeOut();
        initmag();
        //$("#addGTD").fadeIn();
    });

    //点击remark
    $("#magrem").click(function () {

        $("#magremin").slideToggle();

    });
});

$("#timeview").ready(function () {
    var a;//判断点击的事today还是。。。。
    var flag = 0;
    //展示事件用的变量
    var disp = 0;
    //展示事件的函数
    function linedis() {
        if (a == "#tvtoday") {
            dis = showtodayGTD();
        }
        else if (a == "#tvtomo") {
            dis = showtomrrowGTD();
        }
        else if (a == "#tvhis") {
            dis = showhistoryGTD();
        }
        else if (a == "#tvfutu") {
            dis = showfutureGTD();
        }
        if (dis != null) {
            //if (disp >= dis.length) disp = 0;
            for (var i = 0; i < 6; i++) {
                var tvb = "#tvb" + i;
                if (disp >= dis.length) {
                    //$(tvb).hide();
                    disp = 0;
                    $(tvb).html(dis[disp].GTDdes);
                    $(tvb).append("<br />");
                    $(tvb).append(dis[disp].GTDdate);
                    $(tvb).append("  ");
                    $(tvb).append(dis[disp].GTDtime);
                    $(tvb).append("<br />");
                    switch (dis[disp].GTDlevel) {
                        case '5':
                            $(tvb).css("background-color", "#FF0000")
                            $(tvb).css("color", "#FFFFFF")
                            break;
                        case '4':
                            $(tvb).css("background-color", "#FF8040")
                            $(tvb).css("color", "#000000")
                            break;
                        case '3':
                            $(tvb).css("background-color", "#FFFF37")
                            $(tvb).css("color", "#000000")
                            break;
                        case '2':
                            $(tvb).css("background-color", "#A8FF24")
                            $(tvb).css("color", "#000000")
                            break;
                        case '1':
                            $(tvb).css("background-color", "#00FFFF")
                            $(tvb).css("color", "#000000")
                            break;
                        case '0':
                            $(tvb).css("background-color", "#00FFFF")
                            break;

                    }
                    $(tvb).attr("title", disp);
                }
                else {
                    $(tvb).show();
                    $(tvb).html(dis[disp].GTDdes);
                    $(tvb).append("<br />");
                    $(tvb).append(dis[disp].GTDdate);
                    $(tvb).append("  ");
                    $(tvb).append(dis[disp].GTDtime);
                    $(tvb).append("<br />");
                    switch (dis[disp].GTDlevel) {
                        case '5':
                            $(tvb).css("background-color", "#FF0000")
                            $(tvb).css("color", "#FFFFFF")
                            break;
                        case '4':
                            $(tvb).css("background-color", "#FF8040")
                            $(tvb).css("color", "#000000")
                            break;
                        case '3':
                            $(tvb).css("background-color", "#FFFF37")
                            $(tvb).css("color", "#000000")
                            break;
                        case '2':
                            $(tvb).css("background-color", "#A8FF24")
                            $(tvb).css("color", "#000000")
                            break;
                        case '1':
                            $(tvb).css("background-color", "#00FFFF")
                            $(tvb).css("color", "#000000")
                            break;
                        case '0':
                            $(tvb).css("background-color", "#00FFFF")
                            break;

                    }
                    $(tvb).attr("title", disp);
                }
                disp++;
            }
        }

    }
    //点击条目的函数
    function lineclick() {
        if (flag == 0) {
            flag = 1;
            $(".tvline").fadeOut(300);
            setTimeout(function () { $(a).css("border-color", "white"); }, 300);
            $(a).fadeIn();
            setTimeout(function () { $("#tvdis").slideDown(); }, 1000);
            //初始化事件列表
            disp = 0;
            linedis();
        }
        else if (flag == 1) {
            $(a).fadeOut(900);
            $("#tvdis").slideUp(900);
            setTimeout(function () {
                $(a).css("border-color", "black")
                $(".tvline").fadeIn();
            }, 1000);
            flag = 0;
        }
        else;
    }
    $("#tvtoday").click(function () {
        a = "#tvtoday";
        lineclick();
    });
    $("#tvtomo").click(function () {
        a = "#tvtomo";
        lineclick();
    });
    $("#tvhis").click(function () {
        a = "#tvhis";
        lineclick();
    });
    $("#tvfutu").click(function () {
        a = "#tvfutu";
        lineclick();
    });
    //左右滑动翻页
    $("#tvdis").hammer().on("swiperight", function (ev) {
        linedis();
        $(".tvblock").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".tvblock").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#tvdis").hammer().on("swipeleft", function (ev) {
        for (var i = 0; i < 12; i++) {
            disp--;
            if (disp < 0) disp = dis.length - 1;
        }
        linedis();
        $(".tvblock").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".tvblock").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".tvblock").click(function () {
        if (dis[$(this).attr("title")].GTDno != -1) {
            readGTDjson(dis[$(this).attr("title")]);
            $("#disGTD").fadeIn();
        }

    });
});

$("#locview").ready(function () {
    ///初始化地点展示窗
    loc = displayAllLoc();
    var page = 0;//展示地点用的计数变量
    for (var i = 0; i < 6; i++) {
        var lvb = "#lvb" + i;
        if (page >= loc.length) {
            page = 0;
            $(lvb).html(loc[page].locname);
            $(lvb).attr("title", page);
        }
        else {
            $(lvb).html(loc[page].locname);
            $(lvb).attr("title", page);
        }
        page++;
    }
    //定义展示事件用的变量
    var disp = 0;

    $("#locview").hammer().on("swipedown", function (ev) {
        $("#addloc").slideDown();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#locview").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var lvb = "#lvb" + i;
            if (page >= loc.length) {
                page = 0;
                $(lvb).html(loc[page].locname);
                $(lvb).attr("title", page);
            }
            else {
                $(lvb).html(loc[page].locname);
                $(lvb).attr("title", page);
            }
            page++;
        }
        $(".lvb").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".lvb").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });

    $(".lvb").click(function () {
        //根据选择初始化展示事件的变量
        var name = loc[$(this).attr("title")].locname;
        dis = displaylocGTD(loc[$(this).attr("title")].locname);
        dispage = 0;
        WinJS.UI.processAll();
        //初始化展示
        for (var i = 0; i < 6; i++) {
            var lvd = "#lvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvb).append("  ");
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            else {
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvb).append("  ");
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            dispage++;
        }
        $("#lvdishead").html(loc[$(this).attr("title")].locname);
        $("#lvdis").fadeIn();
    });
    $("#lvdis").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var lvd = "#lvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            else {
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".lvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".lvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#lvdis").hammer().on("swipeleft", function (ev) {
        for (var i = 0; i < 12; i++) {
            dispage--;
            if (dispage < 0) dispage = dis.length - 1;
        }
        for (var i = 0; i < 6; i++) {
            var lvd = "#lvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            else {
                $(lvd).html(dis[dispage].GTDdes);
                $(lvd).append("<br />");
                $(lvd).append(dis[dispage].GTDdate);
                $(lvd).append(dis[dispage].GTDtime);
                $(lvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(lvd).css("background-color", "#FF0000")
                        $(lvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(lvd).css("background-color", "#FF8040")
                        $(lvd).css("color", "#000000")
                        break;
                    case '3':
                        $(lvd).css("background-color", "#FFFF37")
                        $(lvd).css("color", "#000000")
                        break;
                    case '2':
                        $(lvd).css("background-color", "#A8FF24")
                        $(lvd).css("color", "#000000")
                        break;
                    case '1':
                        $(lvd).css("background-color", "#00FFFF")
                        $(lvd).css("color", "#000000")
                        break;
                    case '0':
                        $(lvd).css("background-color", "#00FFFF")
                        break;

                }
                $(lvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".lvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".lvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#lvdishead").click(function () {
        $("#lvdis").fadeOut();
    });
    $(".lvd").click(function () {
        if (dis[$(this).attr("title")].GTDno != -1) {
            readGTDjson(dis[$(this).attr("title")]);
            $("#disGTD").fadeIn();
        }

    });
});

$("#addloc").ready(function () {
    $("#addloc").hammer().on("swipeup", function (ev) {
        $("#addloc").slideUp();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#alok").click(function () {
        addCustomerLoc();
        locviewready();
        disGTDready();
        magGTDready();
        $("#addloc").slideUp();
        //$("#locview").show();
    });
    $("#alcan").click(function () {
        $("#addloc").slideUp();
        //$("#locview").show();
    });
});

$("#fileview").ready(function () {
    //展示文件夹的变量以及初始化
    file = displayAllFile();
    var page = 0;
    for (var i = 0; i < 6; i++) {
        var fvb = "#fvb" + i;
        if (page >= file.length) {
            page = 0;
            $(fvb).html(file[page].filename);
            $(fvb).attr("title", page);
        }
        else {
            $(fvb).html(file[page].filename);
            $(fvb).attr("title", page);
        }
        page++;
    }
    //定义展示事件用的变量
    var disp = 0;


    $("#fileview").hammer().on("swipedown", function (ev) {
        $("#addfile").slideDown();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#fileview").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var fvb = "#fvb" + i;
            if (page >= file.length) {
                page = 0;
                $(fvb).html(file[page].filename);
                $(fvb).attr("title", page);
            }
            else {
                $(fvb).html(file[page].filename);
                $(fvb).attr("title", page);
            }
            page++;
        }
        $(".fvb").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".fvb").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".fvb").click(function () {
        //根据选择初始化展示事件的变量
        //dis = getGTD(loc[$(this).attr("title")].locno);
        dis = displayfileGTD(file[$(this).attr("title")].filename);
        dispage = 0;
        WinJS.UI.processAll();
        //初始化展示
        for (var i = 0; i < 6; i++) {
            var fvd = "#fvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            else {
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            dispage++;
        }
        $("#fvdishead").html(file[$(this).attr("title")].filename);
        $("#fvdis").fadeIn();
    });
    $("#fvdis").hammer().on("swiperight", function (ev) {
        for (var i = 0; i < 6; i++) {
            var fvd = "#fvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            else {
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".fvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".fvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#fvdis").hammer().on("swipeleft", function (ev) {
        for (var i = 0; i < 12; i++) {
            dispage--;
            if (dispage < 0) dispage = dis.length - 1;
        }
        for (var i = 0; i < 6; i++) {
            var fvd = "#fvd" + i;
            if (dispage >= dis.length) {
                dispage = 0;
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            else {
                $(fvd).html(dis[dispage].GTDdes);
                $(fvd).append("<br />");
                $(fvd).append(dis[dispage].GTDdate);
                $(fvb).append("  ");
                $(fvd).append(dis[dispage].GTDtime);
                $(fvd).append("<br />");
                switch (dis[dispage].GTDlevel) {
                    case '5':
                        $(fvd).css("background-color", "#FF0000")
                        $(fvd).css("color", "#FFFFFF")
                        break;
                    case '4':
                        $(fvd).css("background-color", "#FF8040")
                        $(fvd).css("color", "#000000")
                        break;
                    case '3':
                        $(fvd).css("background-color", "#FFFF37")
                        $(fvd).css("color", "#000000")
                        break;
                    case '2':
                        $(fvd).css("background-color", "#A8FF24")
                        $(fvd).css("color", "#000000")
                        break;
                    case '1':
                        $(fvd).css("background-color", "#00FFFF")
                        $(fvd).css("color", "#000000")
                        break;
                    case '0':
                        $(fvd).css("background-color", "#00FFFF")
                        break;

                }
                $(fvd).attr("title", dispage);
            }
            dispage++;
        }
        $(".fvd").css({
            "animation": "blockturning 1.5s",
        });
        setTimeout(function () {
            $(".fvd").css({
                "animation": "none 0.1s",
            });
        }, 1500);
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#fvdishead").click(function () {
        $("#fvdis").fadeOut();
    });
    $(".fvd").click(function () {
        if (dis[$(this).attr("title")].GTDno != -1) {
            readGTDjson(dis[$(this).attr("title")]);
            $("#disGTD").fadeIn();
        }

    });

});

$("#addfile").ready(function () {
    $("#addfile").hammer().on("swipeup", function (ev) {
        $("#addfile").slideUp();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $("#afok").click(function () {
        addCustomerFile();
        fileviewready();
        magGTDready();
        disGTDready();
        $("#addfile").slideUp();
        //$("#locview").show();
    });
    $("#afcan").click(function () {
        $("#addfile").slideUp();
        //$("#locview").show();
    });
});

$("#disGTD").ready(function () {
        var imgsrc = getimg();
        for (var i = 0; i < imgsrc.length; i++) {
            $("#disgimgin").append("<option value =\"" + imgsrc[i].src + "\">" + imgsrc[i].name + "</option>");
        }
        ////图片选择器初始化设置完毕


        //初始化地点和文件列表
        loc = displayAllLoc();
        file = displayAllFile();
        for (var i = 0; i < loc.length; i++) {
            $("#disglocin").append("<option value =\"" + loc[i].locname + "\">" + loc[i].locname + "</option>");
        }
        for (var i = 0; i < file.length; i++) {
            $("#disgfilein").append("<option value =\"" + file[i].filename + "\">" + file[i].filename + "</option>");
        }
        //地点文件列表初始化完毕
        // 初始化各个输入变量
        function initdisGTD() {
            $("#disgnamein").val("");
            $("#disgremin").html("");
            //$("#disgimgdis").attr("src", "images/time.png");
            //imgsrc = "images/time.png";
            document.getElementById("disgimgdis").src = imgsrc[0].src;
            var rp = document.getElementById("disglevelin").winControl;
            rp.userRating = 0;
            var now = new Date();
            var dp = document.getElementById("disgdate").winControl;
            dp.current = now;
            var tp = document.getElementById("disgtime").winControl;
            tp.current = now;
            var title = document.getElementById("disglocin");
            title.options[0].selected = true;
            title = document.getElementById("disgfilein");
            title.options[0].selected = true;
            title = document.getElementById("disgimgin");
            title.options[0].selected = true;
        }
        //改变选择图片
        $("#disgimgin").change(function () {
            document.getElementById("disgimgdis").src = $("#disgimgin").val();
        });
        //点击ok
        $("#disgok").click(function () {
            WinJS.UI.processAll();
            delGTD($("#disgdele").attr("title"));
            editGTD($("#disgdele").attr("title"));
            $("#disGTD").fadeOut();
            locviewready();
            fileviewready();
            timeviewready();
            initdisGTD();
            //添加修改内容
        });
        //点击cancel
        $("#disgcan").click(function () {
            $("#disGTD").fadeOut();
            initdisGTD();
        });
        //点击delete
        $("#disgdele").click(function () {
            delGTD($("#disgdele").attr("title"));
            $("#disGTD").fadeOut();
            locviewready();
            fileviewready();
            timeviewready();
            initdisGTD();
        });
        $("#disgrem").click(function () {

            $("#disgremin").slideToggle();

        });
});

$("#addstyle").ready(function () {
    //初始化图片列表
    var imgsrc = getimg();
    for (var i = 0; i < imgsrc.length; i++) {
        $("#adsimgin").append("<option value =\"" + imgsrc[i].src + "\">" + imgsrc[i].name + "</option>");
    }
    //默认显示第一个
    document.getElementById("adsimgdis").src = imgsrc[0].src;
    $("#adsimgin").change(function () {

        document.getElementById("adsimgdis").src = $("#adsimgin").val();
    });
    //初始化设置完毕
    $("#adsok").click(function () {

        addCustomerStyle();

        addGTDready();
        deleteGTDready();
        $("#adsnamein").attr("value", "");
        document.getElementById("adsimgdis").src = imgsrc[0].src;
        var title = document.getElementById("adsimgin");
        title.options[0].selected = true;
    });
    $("#addstyle").hammer().on("swipedown", function (ev) {
        $("#delestyle").slideDown();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
});

$("#delestyle").ready(function () {
    style = displayAllStyle();
    for (var i = 0; i < style.length; i++) {
        var n = style[i].sname;
        var img = style[i].simg;
        $("#delestyle").append("</div>");
        $("#delestyle").append("</div>");
        $("#delestyle").append("<div class='delebutton' id=" + style[i].sno + ">DELETE");
        $("#delestyle").append("<img src=" + img + " class='deleimg'/>");
        $("#delestyle").append("<div class='delediv' title=" + i + ">" + n);
    }
    $("#delestyle").hammer().on("swipeup", function (ev) {
        $("#delestyle").slideUp();
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".delediv").hammer().on("swipeleft", function (ev) {
        var but = style[$(this).attr("title")].sno;
        var i = $("#" + but).css("width");
        if ($("#" + but).css("width") == "0px") $("#" + but).animate({ width: '30%' });;
        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".delediv").hammer().on("swiperight", function (ev) {
        var but = style[$(this).attr("title")].sno;
        if ($("#" + but).css("width") != "0px") $("#" + but).animate({ width: '0%' });

        ev.gesture.preventDefault();
        ev.stopPropagation();
    });
    $(".delebutton").click(function () {
        var but = $(this).attr("id");
        delStyle(but);
        $("#" + but).animate({ width: '0%' });
        addGTDready();
        deleteGTDready();
        $("#delestyle").slideUp();
    });
});

